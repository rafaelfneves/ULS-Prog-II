#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <time.h>
#include <locale.h>
#include <conio.h>

#include "colors.h"
#include "header2.h"

int main(){
	system("cls");
	setlocale(LC_ALL, "Portuguese");
	
	CLIENTES listaClientes;
	PRODUTOS listaProdutos;
	LOGINS   listaLogins;
	VENDAS   listaVendas;
	DADOS    qtd;
	LOG      listaLogs;
	URL      end;
	
	int opcao; // recebe a opcao dos menus
	int idVenda; // recebe o id do cliente para a venda
	
	defineCaminhos     (&end);	
	verificaIntegridade(end, &qtd);
	verificaJuros      (end, qtd);
	verificaSaldos     (end, qtd);
	
	do{
		qtd.Ocorrencias = verificaOcorrencias(end, qtd);                                            // verifica a exist�ncia de novos logs
		cabecalho(qtd);																				// imprime o cabe�alho
		opcao = menuPrincipal();																	// mostra o menu principal
		switch(opcao){
			case 1:
				cabecalho(qtd);
				opcao = menuClientes();
				switch(opcao){
					case 1: // cadastra clientes
						cabecalho(qtd);
						qtd.Clientes = cadastraClientes(end, qtd, listaClientes, listaLogs);
						break;
					case 2: // altera clientes
						cabecalho(qtd);
						alteraClientes(end, qtd, listaClientes, listaLogs);
						break;
				}
				break;
				//fim op��o clientes
			case 2:
				cabecalho(qtd);
				opcao = menuProdutos();
				switch(opcao){
					case 1: // cadastra produtos
						cabecalho(qtd);
						qtd.Produtos = cadastraProdutos(end, qtd, listaProdutos, listaLogs);
						break;
					case 2: // altera os produtos
						cabecalho(qtd);
						alteraProdutos(end, qtd, listaProdutos, listaLogs);
						break;
					case 3: //adiciona produtos ao estoque
						cabecalho(qtd);
						adicionaEstoque(end, qtd, listaProdutos, listaLogs);
						break;
				}
				break;
				//fim opc�o produtos
			case 3:
				cabecalho(qtd);
				opcao = menuVendas();
				switch(opcao){
					case 1: //venda a vista
						cabecalho(qtd);
						qtd.Vendas = vender(0, end, qtd, listaClientes, listaProdutos, listaVendas, listaLogs);
						break;
					case 2: //venda a prazo
						idVenda = pegaId(end, qtd);
						if (idVenda == 0) break;
						else qtd.Vendas = vender(idVenda, end, qtd, listaClientes, listaProdutos, listaVendas, listaLogs);
						break;
				}
				break;
			case 4: // fazer pagamentos
				cabecalho(qtd);
				imprimeClientes(2, end, qtd, listaClientes);
				fazPagamento(end, qtd, listaLogs);
				break;
			case 5:
				//listagens
				cabecalho(qtd);
				opcao = menuListagens();
				if (opcao == 0){
					opcao = 1;
					break;
				}
				cabecalho(qtd);
				listagens(opcao, end, qtd, listaClientes, listaProdutos);
				break;
			case 6:
				// ler logs
				cabecalho(qtd);
				lerLogs(end, qtd, listaLogs);
				break;
			case 7:
				// fechar caixa
				cabecalho(qtd);
				printf ("-=- MENU CAIXA -=-\n\n1 - Fechar caixa\n2 - Visualizar caixa\n\nEscolha sua op��o: ");
				do{
					scanf ("%d", &opcao);
					if (opcao < 0 || opcao > 2){
						FOREYELLOW;
						printf ("Op��o inv�lida, tente novamente: ");
						FOREWHITE;
					}
				} while (opcao < 0 || opcao > 2);
				cabecalho(qtd);
				switch(opcao){
					case 0:
						opcao = 1;
						break;
					case 1:
						cabecalho(qtd);
						fecharCaixa(end, qtd);	
						break;
					case 2:
						visualizarCaixa(qtd);
						break;
					}
				break;
			case 0:
				printf ("SAIR");
				break;
		}
	} while (opcao != 0);
	return 0;
}

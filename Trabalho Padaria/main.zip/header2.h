//estrutura de todos os endere�os dos arquivos
typedef struct{
	char clientes[100], produtos[100], logins[100], log[100], vendas[100];
}URL;

//estrutura de cada compra feita
typedef struct{
	int quantidade, cod;
	float preco;
	char nome[100];
}COMPRAS;

//estrutura de cada cliente
typedef struct{
	int id;								// id de cadastro do cliente
	int compras; 						// quantas compras que ele tem ativas
	int diasDevidos; 					// quantidade de dias devididos pelo cliente em sua compra mais antiga
	char nome[100]; 					// nome completo do cliente
	char endereco[100]; 				// endereco completo do cliente
	float saldoDevedor; 				// saldo devedor completo de todas as compras feitas
	float jurosDevidos;                 // total de juros devido pelo cliente
	float totalDevidos;					// total devido (compra + juros)
}CLIENTES;

typedef struct{
	int cod;							//id de cadastro do produto
	int qtd;							//quantidade deste produto em estoque
	int qtdVendidas;					// quantos itens j� foram vendidos deste produto
	int qtdBaixas;						// quantas o vendedor deseja ser informado quando a quantidade estiver
	char nome[100];						// nome do produto
	float preco;						// pre�o praticado pelo estabelecimento
}PRODUTOS;

// estrutura das quantidade de cada um dos itens
typedef struct{
	int Clientes;
	int Produtos;
	int Logins;
	int Ocorrencias;
	int Vendas;
}DADOS;

//estrutura das senhas cadastradas no programa -=- n�o implementado -=-
typedef struct{
	int nivel;							// nivel de permiss�o do usu�rio 1- MASTER / 2 - Usu�rio master/ 3 - Usu�rio 
	char user[20];						//receber� o login de usu�rio
	char senha[20];						// receber� a senha determinada pelo usu�rio
	char nome;							// receber� o nome do usu�rio
}LOGINS;

// estrutura de todas as a��es feitas por usu�rios no programa
typedef struct{
	int cod; 							//codigo do produto que teve seu nome ou quantidade alteradas
	int id; 							// id do cliente que executou tal a��o
	int estoqueAntigo;                  // adiciona ao log o estoque anteiormente existente
	int estoqueAdicionado; 				// estoque do produto que fora adicionado
	int opcao;							// opcao de altera��o feita
	int compraid;						// recebe o id referente a qual numero de compra feita
	float precoNovo;					// pre�o atualizado de determinado produto
	float precoAnterior;				// pre�o anterior de determinado produto
	float vendaTotal;					// venda total de determinado cliente
	float saldoAtual; 					// saldo ap�s o cliente fazer determinada compra
	float saldoAnterior;				// saldo antes de efetuado quaisquer pagamentos
	float pagamento;					// o montante pago por determinado cliente
 	char momento[20];					// o momento que tal a��o fora executada
	char nome[100];						// o nome atualizado de determinado cliente
	char nomeVelho[100];				// o nome anterior de determinado cliente
 	char endereco[100];					// o endere�o atualizado de determinado cliente
	char enderecoVelho[100];			// o endere�o anterior de determinado cliente
}LOG;

// estrutura de todas as vendas j� realizadas
typedef struct{
	int id;								// recebe o ID do cliente que fez a compra, 0 quando a venda for a vista
	int compraid;						// recebe o ID da compra que foi feita
	int ano, mes, dia, hora, min, seg;  // variaveis para receber o momento que ocorreu tal a��o
	int quantidade; 					// recebe quantos produtos foram comprados por tal cliente 
	float compra;						// incide a compra de todos os itens
	float juros;						// recebe o montante de juros incididos na compra
	float compraTotal;         			// recebe compra + juros
	float saldoDevedor;					// receber o montante da compra total, mas o d�bito de pagamentos acontecer� nele
	COMPRAS lista[100];                 // lista de produtos que foram adquiridos em determinada venda
}VENDAS;

// PROTOTIPOS
void debug(DADOS qtd);
void pegaMomento(VENDAS *listaVendas);
void pegaInstante(char frase[]);

void imprimeVendas  (int num,URL end, DADOS qtd);
void imprimeClientes(int num, URL end, DADOS qtd, CLIENTES listaClientes);
void imprimeProdutos(int num, URL end, DADOS qtd, PRODUTOS listaProdutos);

// --------------------------------------------------------------------- FUN��ES ----------------------------------------------------------------------------- //

// ------------------------------------------------ //
// ---------------      DIVERSAS     -------------- //
// ------------------------------------------------ //
												
// titulo
void titulo(){
	printf ("  _    _ _   _   _          _                     _      ___       _                \n"""	);
	printf (" | |  (_) |_| |_| |___   _ | |___  __ _ _ _  __ _( )___ | _ ) __ _| |_____ _ _ _  _  \n");
	printf (" | |__| |  _|  _| / -_) | || / _ \\/ _` | ' \\/ _` |/(_-< | _ \\/ _` | / / -_) '_| || | \n");
	printf (" |____|_|\\__|\\__|_\\___|  \\__/\\___/\\__,_|_||_\\__,_| /__/ |___/\\__,_|_\\_\\___|_|  \\_, | \n");
	printf ("                                                                               |__/  \n");
}

//insere o cabe�alho - limpa a tela e insere t�tulo
void cabecalho(DADOS qtd){
	system("cls");
	debug(qtd);
	titulo();
}

// debug - informa as quantidades
void debug(DADOS qtd){
	printf (" -=- DEBUG -=-\nQuantidade clientes = %d\nQuantidade produtos = %d\nQuantidade logins = %d\nQuantidade de vendas totais = %d\nQuantidade de ocorrencias do dia = %d\n\n", qtd.Clientes, qtd.Produtos, qtd.Logins, qtd.Vendas, qtd.Ocorrencias);
}

// pega o dia em forma de ponteiro para formar o caminho do log
void pegaDia(char atual[]){
	int dia, mes, ano;
	struct tm *data_hora_atual;
	time_t segundos;
	time(&segundos);
	data_hora_atual = localtime(&segundos);
	ano = data_hora_atual->tm_year + 1900;
	mes = data_hora_atual->tm_mon + 1;
	dia = data_hora_atual->tm_mday;
	snprintf(atual, 20, "%2.d%.2d%.2d", ano, mes, dia);
}

// pega o dia, mes e ano por parametro e retorna os mesmos
void pegaIntDia(int *dia, int *mes, int *ano){
	struct tm *data_hora_atual;
	time_t segundos;
	time(&segundos);
	data_hora_atual = localtime(&segundos);
	*dia = data_hora_atual->tm_mday;
	*mes = data_hora_atual->tm_mon + 1;
	*ano = data_hora_atual->tm_year + 1900;
}

// pega o caminho do log do dia e insere no string passado por par�metro
void caminhoLog(char log[]){
	char atual[20];
	pegaDia(atual);
	snprintf (log, 20, "Logs\\%s.log", atual);
}

// ------------------------------------------------ //
// ---------------       MENUS       -------------- //
// ------------------------------------------------ //
												
// menu principal - retornando um inteiro como op��o selecionada pelo usu�rio limitando-se a quantidade existente de op��es												
int menuPrincipal(){
	int opcao;
	printf ("-=- MENU PRINCIPAL -=-\n\n1 - Clientes\n2 - Produtos\n3 - Vendas\n4 - Pagamento\n5 - Listagens\n6 - Logs\n7 - Fechar caixa\n\n0 - Sair do programa\n\nEscolha sua op��o: ");
	do{
		scanf("%d", &opcao);
		if (opcao < 0 || opcao > 7){
			FOREYELLOW;
			printf ("Op��o inv�lida, tente novamente: ");
			FOREWHITE;
		}
	} while (opcao < 0 || opcao > 7);
	return opcao;
}

// menu clientes - apresenta o menu de clientes e retorna a op��o desejada
int menuClientes(){
	int opcao;
	printf ("-=- MENU CLIENTES -=-\n\n1 - Cadastrar\n2 - Altera��o de cadastro\n\n0 - Voltar ao menu principal\n\nEscolha sua op��o: ");
	do{
		scanf("%d", &opcao);
		if (opcao < 0 || opcao > 2){
			FOREYELLOW;
			printf ("Op��o inv�lida, tente novamente: ");	
			FOREWHITE;
		}
		if (opcao == 0) return 999;
	} while (opcao < 0 || opcao > 2);
	return opcao;
}

// -=- apresenta o menu de produtos retornando a opcao escolhida -=-
int menuProdutos(){
	int opcao;
	printf ("-=- MENU Produtos -=-\n\n1 - Cadastrar\n2 - Altera��o de cadastro\n3 - Adicionar estoque\n\n0 - Voltar ao menu principal\n\nEscolha sua op��o: ");
	do{
		scanf("%d", &opcao);
		if (opcao < 0 || opcao > 3){
			FOREYELLOW;
			printf ("Op��o inv�lida, tente novamente: ");	
			FOREWHITE;	
		}
	} while (opcao < 0 || opcao > 3);
	if (opcao == 0) return 999;
	return opcao;
}

// -=- MENU VENDAS -=- apresenta o menu de vendas retornando a op��o escolhida
int menuVendas(){
	int opcao;
	printf ("-=- MENU Vendas -=-\n\n1 - A vista\n2 - A fiado\n\n0 - Voltar ao menu principal\n\nEscolha a sua op��o: ");
	do{
		scanf("%d", &opcao);
		if (opcao < 0 || opcao > 2){
			FOREYELLOW;
			printf ("Op��o inv�lida, tente novamente: ");
			FOREWHITE;
		}
	} while (opcao < 0 || opcao > 2);
	return opcao;
}

// -=- MENU LISTAGENS -=- apresenta todas as listagens dispon�veis para o usu�rio retornando a op��o escolhida
int menuListagens(){
	int opcao;
	printf ("-=- MENU Vendas -=-\n\n1 - Listagens de clientes\n2 - Listagens de produtos\n3 - Listagens de Vendas\n\nEscolha a sua op��o: ");
	do{
		scanf("%d", &opcao);
		if (opcao < 0 || opcao > 4){
			FOREYELLOW;
			printf ("Op��o inv�lida, tente novamente: ");
			FOREWHITE;
		}
	} while (opcao < 0 || opcao > 4);
	return opcao;
}

//listagens - d� ao usu�rio todos os tipos de listagens existentes
void listagens(int opcao, URL end, DADOS qtd, CLIENTES listaClientes, PRODUTOS listaProdutos){
	int i, opcao2;
	VENDAS listaVendas[qtd.Vendas];
	FILE *p = fopen(end.vendas, "rb");
	fread(&listaVendas, sizeof(VENDAS), qtd.Vendas, p);
	fclose(p);
	cabecalho(qtd);
	switch(opcao){
		case 1: // clientes
			printf ("-=- Listagem de clientes -=-\n\n1 - Todos os clientes\n2 - Clientes devedores\n3 - Clientes quitados\n\nEscolha sua op��o: ");
			do{
				scanf ("%d", &opcao2);
				if (opcao2 < 0 || opcao2 > 3) printf ("Op��o inv�lida, tente novamente: ");
			} while (opcao2 < 0 || opcao2 > 3);
			cabecalho(qtd);
			if (opcao2 == 0) return;
			else{
				switch(opcao2){
					case 1:
						imprimeClientes(1, end, qtd, listaClientes); //todos os clientes s�o impressos
						printf ("\nAperte qualquer bot�o para continuar... ");
						getch();
						break;
					case 2:
						imprimeClientes(2, end, qtd, listaClientes); // todos os clientes devedores s�o impressos
						printf ("\nAperte qualquer bot�o para continuar... ");
						getch();
						break;
					case 3:
						imprimeClientes(3, end, qtd, listaClientes); // todos os clientes quitados s�o impressos
						printf ("\nAperte qualquer bot�o para continuar...");
						getch();
						break;
				}
			}
			break;
		case 2: // produtos
			printf ("-=- Listagem de produtos -=-\n\n1 - Todos os produtos\n2 - Produtos com o estoque baixo\n*** 3 - Produtos mais vendidos ***\n\nEscolha sua op��o: ");
			do{
				scanf ("%d", &opcao2);
				if (opcao2 < 0 || opcao2 > 3) printf ("Op��o inv�lida, tente novamente: ");
			} while (opcao2 < 0 || opcao2 > 3);
			if (opcao2 == 0) return;
			else{
				switch(opcao2){
					case 1:
						imprimeProdutos(1, end, qtd, listaProdutos);
						printf ("Aperte qualquer bot�o para continuar...");
						getch();
						break;
					case 2:
						imprimeProdutos(2, end, qtd, listaProdutos);
						printf ("Aperte qualquer bot�o para continuar...");
						getch();
						break;
					case 3:
						printf ("Em constru��o...");
						printf ("Aperte qualquer bot�o para continuar...");
						getch();
						break;
				}
			}
			break;
		case 3: //vendas
			printf ("-=- Listagens de vendas -=-\n\n1 - Todas as vendas\n2 - Vendas ativas\n3 - Vendas quitadas\n4 - Vendas por ID\n\nEscolha sua op��o: ");
			do{
				scanf ("%d", &opcao2);
				if (opcao2 < 0 || opcao2 > 4) printf ("Op��o inv�lida, tente novamente: ");
			} while (opcao2 < 0 || opcao2 > 4);
			cabecalho(qtd);
			if (opcao2 == 0) return;
			else{
				switch(opcao2){
					case 1: // todas as vendas
						imprimeVendas(1, end, qtd);
						printf ("Aperte qualquer bot�o para continuar...");
						getch();
						break;
					case 2: // vendas ativas
						imprimeVendas(2, end, qtd);
						printf ("Aperte qualquer bot�o para continuar...");
						getch();
						break;
					case 3: //
						imprimeVendas(3, end, qtd);
						printf ("Aperte qualquer bot�o para continuar...");
						getch();
						break;
					case 4: // busca a compra em espec�fico
						imprimeVendas(1, end, qtd);
						printf ("\nInsira o ID da venda a ser pesquisada: ");
						do{
							scanf ("%d", &opcao);
							
						} while (opcao < 0 || opcao > qtd.Vendas);
						if(opcao == 0) break;
						else{
							cabecalho(qtd);
							if(listaVendas[opcao - 1].id == 0) printf ("Compra feita a vista.\n");
							else{
								printf ("Compra feita a fiado pelo clientes ID: %d", listaVendas[opcao - 1].id);
								p = fopen(end.clientes, "rb");
								fseek(p, (listaVendas[opcao - 1].id - 1) * sizeof(CLIENTES), SEEK_SET);
								fread (&listaClientes, sizeof(CLIENTES), 1, p);
								fclose(p);
								printf (" - %s\nSaldo devedor: %2.2f\n", listaClientes.nome, listaClientes.saldoDevedor);
							}
							printf ("\nCOD\tNOME\tQTD\tPRE�O\n");
							for(i = 0; i < listaVendas[opcao - 1].quantidade; i++){
								printf ("%d\t%s\t%d\t%2.2f\n", listaVendas[opcao - 1].lista[i].cod, listaVendas[opcao - 1].lista[i].nome, listaVendas[opcao - 1].lista[i].quantidade, listaVendas[opcao - 1].lista[i].preco);
							}
							printf ("\nTotal da venda: %2.2f\nTotal devedor da compra: %2.2f", listaVendas[opcao - 1].compraTotal, listaVendas[opcao - 1].saldoDevedor);
							getch();
						}
						break;
				}
			}
			break;
	}
}

//fun��o que d� ao usu�rio oportunidade de fazer a leitura de cada log gerado pelo sistema
void lerLogs(URL end, DADOS qtd, LOG listaLogs){
	int i, dia, mes, ano;
	char data[20];
	printf ("Entre com a data pretendida:\n\nDia: ");
	scanf ("%d", &dia);
	printf ("M�s: ");
	scanf ("%d", &mes);
	printf ("Ano: ");
	scanf ("%d", &ano);
	if(ano < 2000) ano += 2000;
	snprintf (data, 20, "Logs\\%d%.2d%.2d.log", ano, mes, dia);
	FILE *p = fopen(data, "rb");
	if(!p){
		FOREYELLOW;
		printf ("\nArquivo log n�o encontrado. Tente outra data\n");
		FOREWHITE;
	}
	else{
		printf ("\nArquivo %s encontrado: \n\n", data);
		qtd.Ocorrencias = 0;
		while(fread(&listaLogs, sizeof(LOG), 1, p)) qtd.Ocorrencias++;
		rewind(p);
		if(qtd.Ocorrencias == 0) printf ("N�o h� registros hoje.");
		else{
			for (i = 0; i < qtd.Ocorrencias; i++){
				fread(&listaLogs, sizeof(LOG), 1, p);
				printf ("%s - ", listaLogs.momento);
				switch(listaLogs.cod){
					case 1: // cadastro de cliente
						printf ("Cadastro de cliente - Nome: %s, ID: %d\n", listaLogs.nome, listaLogs.id);
						break;
					case 2: // altera��a de clientes
						if(listaLogs.opcao == 1) printf ("Altera��o de cadastro de cliente - ID: %.2d - Nome antigo: %s - Nome novo: %s\n", listaLogs.id, listaLogs.nomeVelho, listaLogs.nome);
						else printf ("Altera��o de cadastro de cliente - ID: %.2d - Endere�o antigo: %s - Endere�o novo: %s\n", listaLogs.id, listaLogs.enderecoVelho, listaLogs.endereco);
						break;
					case 3: // cadastro de produtos
						printf ("Cadastro de produto ID: %.2d - Nome: %s - Pre�o: R$ %2.2f - Quantidade inicial do estoque: %d\n", listaLogs.id, listaLogs.nome, listaLogs.precoNovo, listaLogs.estoqueAdicionado);
						break;
					case 4: // altera��o de produtos
						if (listaLogs.opcao == 1) printf ("Altera��o de cadastro de produto - ID: %d - Nome antigo: %s - Nome novo: %s\n", listaLogs.id, listaLogs.nomeVelho,listaLogs.nome);    // altera��o do nome do produto
						else printf ("Altera��o de cadastro de produto - ID: %d - Pre�o antigo: %2.2f - Pre�o novo: %2.2f\n", listaLogs.id, listaLogs.precoAnterior, listaLogs.precoNovo);       // altera��o do pre�o do produto
						break;
					case 5: // adi��o no estoque
						printf ("Produtos adicionado ao estoque - ID: %d - Estoque antigo: %d - Adicionados: %d - Total: %d\n", listaLogs.id, listaLogs.estoqueAntigo, listaLogs.estoqueAdicionado - listaLogs.estoqueAntigo, listaLogs.estoqueAdicionado);
						break;
					case 6: // venda a vista
						printf ("Venda a vista - ID compra: %d Total da compra: R$ %2.2f\n", listaLogs.compraid ,listaLogs.vendaTotal);
						break;
					case 7: // venda a fiado
						printf ("Venda a fiado - ID: %d - ID compra: %d - Total da compra: R$ %2.2f\n", listaLogs.id, listaLogs.compraid, listaLogs.vendaTotal);
						break;
					case 8: // pagamentos feitos 
						printf ("Pagamento efetuado - ID: %d - Saldo anterior: R$ %2.2f - Pagamento: R$ %2.2f - Saldo atual: %2.2f\n", listaLogs.id, listaLogs.saldoAnterior, listaLogs.pagamento, listaLogs.saldoAtual);
						break;
					case 9:
						printf ("Caixa do dia encerrado\n");
						break;
				}
			}
		}
		FOREYELLOW;
		printf ("\n\n-=- FIM DE LOG -=-");
		FOREWHITE;
	}
	getch();
}

// --------------------------------------------------- //
// --------------        CAIXA      ------------------ //
// --------------------------------------------------- //
/* Fecha caixa
	* pega os codigos de log do dia (6, 7 e 8) e cria um novo arquivo .PVF 
*/
void fecharCaixa(URL end, DADOS qtd){
	int i, dia, mes, ano, ocorrencias = 0, quantidade = 0;
	char diaNoAno[30];
	LOG listaLogs[qtd.Ocorrencias];
	LOG lista[qtd.Ocorrencias];
	//pegar dia atual
	pegaIntDia(&dia, &mes, &ano);
	snprintf (diaNoAno, 30, "Caixa\\%.2d%.2d%.2d.PVF", ano, mes, dia);
	FILE *p = fopen (end.log, "rb");
	fread(&listaLogs, sizeof(LOG), qtd.Ocorrencias, p);
	fclose(p);
	p = fopen(diaNoAno, "wb");
	for(i = 0; i < qtd.Ocorrencias; i++){
		if(listaLogs[i].cod == 6 || listaLogs[i].cod == 7 || listaLogs[i].cod == 8){
			lista[quantidade].compraid      = listaLogs[i].compraid;
			lista[quantidade].vendaTotal    = listaLogs[i].vendaTotal;
			lista[quantidade].compraid      = listaLogs[i].compraid;
			lista[quantidade].saldoAnterior = listaLogs[i].saldoAnterior;
			lista[quantidade].pagamento     = listaLogs[i].pagamento;
			lista[quantidade].saldoAtual    = listaLogs[i].saldoAtual;
			lista[quantidade].cod           = listaLogs[i].cod;
			strcpy(lista[quantidade].momento, listaLogs[i].momento);
			lista[quantidade].id = listaLogs[i].id;
			quantidade++;
			printf ("%d", quantidade);
			getch();
		}
	}
	fwrite(&lista, sizeof(LOG), quantidade, p);
	fclose(p);
	LOG listaFechar;
	listaFechar.cod = 9;
	pegaInstante(listaFechar.momento);
	p = fopen(end.log, "ab");
	fwrite(&listaFechar, sizeof(LOG), 1, p);
	fclose(p);
	FOREYELLOW;
	printf ("\n\nFechando caixa... 3");	
	for(i = 3; i > 0; i--){
		printf ("\b \b%d", i);
		sleep(1);
	}
	FOREWHITE;
}

void visualizarCaixa(DADOS qtd){
	int dia, mes, ano, quantidade = 0;
	float soma = 0;
	char diaCaixa[30];
	LOG listaLogs;
	printf ("-=- LEITURA DE CAIXA -=-\nInsira o dia: ");
	scanf ("%d", &dia);
	printf ("Insira o m�s :");
	scanf ("%d", &mes);
	printf ("Insira o ano: ");
	scanf ("%d", &ano);
	if(ano < 100) ano += 2000;
	snprintf (diaCaixa, 29, "Caixa\\%.2d%.2d%.2d.PVF", ano, mes, dia);
	FILE *p = fopen (diaCaixa, "rb");
	if(!p){
		printf ("\nArquivo de caixa n�o existente.\n\n");
		return;
	}
	else{
		cabecalho(qtd);
		FORECYAN;
		printf ("-=- ARQUIVO DE CAIXA DE %d/%d/%d -=-\n\n", dia, mes, ano);
		FOREWHITE;
		while(fread(&listaLogs, sizeof(LOG), 1, p)){
			printf ("%s - ", listaLogs.momento);
			switch(listaLogs.cod){
				case 6: // venda a vista
					printf ("Venda a vista - ID compra: %d Total da compra: R$ %2.2f\n", listaLogs.compraid ,listaLogs.vendaTotal);
					soma += listaLogs.vendaTotal;
					break;
				case 7: // venda a fiado
					printf ("Venda a fiado - ID: %d - ID compra: %d - Total da compra: R$ %2.2f\n", listaLogs.id, listaLogs.compraid, listaLogs.vendaTotal);
					soma += listaLogs.vendaTotal;
					break;
				case 8: // pagamentos feitos 
					printf ("Pagamento efetuado - ID: %d - Saldo anterior: R$ %2.2f - Pagamento: R$ %2.2f - Saldo atual: %2.2f\n", listaLogs.id, listaLogs.saldoAnterior, listaLogs.pagamento, listaLogs.saldoAtual);
					soma += listaLogs.pagamento;
					break;	
			}
			quantidade++;	
		}
		printf ("\nTotal de: R$ %2.2f\n", soma);
		getch();
	}
}

// insere como char, por paramentro, o caminho de todos os arquivos necess�rios para a execu��o correta do programa
void defineCaminhos(URL *end){
	char log[20];
	strcpy(end->clientes, "Bins\\clientes.bin");
	strcpy(end->produtos, "Bins\\produtos.bin");
	strcpy(end->logins, "Bins\\logins.bin");
	strcpy(end->vendas, "Bins\\vendas.bin");
	caminhoLog(log);
	strcpy(end->log, log);
}

// verifica a integridade dos arquivos retornando as quantidades via ponteiros
void verificaIntegridade(URL end, DADOS *qtd){
	CLIENTES listaClientes;
	PRODUTOS listaProdutos;
	VENDAS   listaVendas;
	LOG      listaLogs;
	mkdir("Bins");
	mkdir("Logs");
	mkdir("PFV");
	mkdir("Caixa");
	qtd->Clientes = 0;
	FILE *p = fopen(end.clientes, "rb");
	if (!p){
		fclose(p);
		p = fopen (end.clientes, "ab");
		fclose(p);
	}
	while (fread(&listaClientes, sizeof(CLIENTES), 1 , p)) qtd->Clientes++;
	qtd->Produtos = 0;
	p = fopen(end.produtos, "rb");
	if (!p){
		fclose(p);
		p = fopen (end.produtos, "ab");
		fclose(p);
	}
	while (fread(&listaProdutos, sizeof(PRODUTOS), 1 , p)) qtd->Produtos++;
	qtd->Vendas = 0;
	p = fopen (end.vendas, "rb");
	if(!p){
		fclose(p);
		p = fopen(end.vendas, "ab");
		fclose(p);
	}
	while (fread(&listaVendas, sizeof(VENDAS), 1, p)) qtd->Vendas++;
	qtd->Ocorrencias = 0;
	p = fopen (end.log, "rb");
	if (!p){
		fclose(p);
		p = fopen(end.log, "ab");
	}
	while(fread(&listaLogs, sizeof(LOG), 1, p)) qtd->Ocorrencias++;
}

int verificaOcorrencias(URL end, DADOS qtd){
	LOG listaLogs;
	qtd.Ocorrencias = 0;
	FILE *p = fopen (end.log, "rb");
	if (!p){
		fclose(p);
		p = fopen(end.log, "ab");
	}
	while(fread(&listaLogs, sizeof(LOG), 1, p)) qtd.Ocorrencias++;	
	return qtd.Ocorrencias;
}

/*fun��o que verifica os juros das compras
   * 
*/

void verificaJuros(URL end, DADOS qtd){
	int i, dia, mes, ano, qtdDiasCompra = 0, qtdDiasAtuais = 0, diferenca;
	VENDAS listaVendas[qtd.Vendas];
	CLIENTES listaClientes[qtd.Clientes];
	struct tm *data_hora_atual;
	time_t segundos;
	time(&segundos);
	data_hora_atual = localtime(&segundos);
	dia = data_hora_atual->tm_mday;
	mes = data_hora_atual->tm_mon + 1;
	ano = data_hora_atual->tm_year + 1900;
	//debug para simular incidencia de juros
	//dia += 10;	
	//dia += 20;
	//dia += 30;
	FILE *p = fopen(end.vendas, "rb");
	fread(&listaVendas, sizeof(VENDAS), qtd.Vendas, p);
	fclose(p);
	p = fopen (end.clientes, "rb");
	fread(&listaClientes, sizeof(CLIENTES), qtd.Clientes, p);
	fclose(p);
	qtdDiasAtuais = verificaData(dia, mes, ano);
	for (i = 0; i < qtd.Vendas; i++){
		listaVendas[i].juros = 0;
		if(listaVendas[i].id != 0 && listaVendas[i].saldoDevedor > 0){
			qtdDiasCompra = verificaData(listaVendas[i].dia, listaVendas[i].mes, listaVendas[i].ano);
			diferenca = qtdDiasAtuais - qtdDiasCompra;
			if      (diferenca >= 10 && diferenca < 20) listaVendas[i].juros = listaVendas[i].compraTotal * 5/100;
			else if (diferenca >= 20 && diferenca < 30) listaVendas[i].juros = listaVendas[i].compraTotal * 10/100;
			else if (diferenca >= 30) listaVendas[i].juros = listaVendas[i].compraTotal * 15/100;
			listaClientes[listaVendas[i].id - 1].diasDevidos = diferenca;
		}
	}
	// salva novos valores (se existirem)
	p = fopen(end.vendas, "wb");
	fwrite(&listaVendas, sizeof(VENDAS), qtd.Vendas, p);
	fclose(p);
	// salva novos saldos devedores (se existirem)
	p = fopen(end.clientes, "wb");
	fwrite(&listaClientes, sizeof(CLIENTES), qtd.Clientes, p);
	fclose(p);
}

void verificaSaldos(URL end, DADOS qtd){
	int i;
	VENDAS   listaVendas[qtd.Vendas];
	CLIENTES listaClientes[qtd.Clientes];	

	FILE *p = fopen(end.vendas, "rb");
	fread(&listaVendas, sizeof(VENDAS), qtd.Vendas, p);
	fclose(p);

	p = fopen(end.clientes, "rb");
	fread(&listaClientes, sizeof(CLIENTES), qtd.Clientes, p);
	fclose(p);

	for(i = 0; i < qtd.Clientes; i++) listaClientes[i].saldoDevedor = 0;
	
	for(i = 0; i < qtd.Vendas; i++){
		if (listaVendas[i].saldoDevedor > 0){
			listaClientes[listaVendas[i].id - 1].jurosDevidos = listaVendas[i].juros;
			listaClientes[listaVendas[i].id - 1].saldoDevedor = listaVendas[i].saldoDevedor;
			listaClientes[listaVendas[i].id - 1].totalDevidos = listaClientes[listaVendas[i].id - 1].jurosDevidos + listaClientes[listaVendas[i].id - 1].saldoDevedor;
		}	
	}
	p = fopen(end.clientes, "wb");
	fwrite (&listaClientes, sizeof(CLIENTES), qtd.Clientes, p);
	fclose(p);
}

// --------------------------------------------------- //
// --------------      CLIENTES     ------------------ //
// --------------------------------------------------- //

int cadastraClientes(URL end, DADOS qtd, CLIENTES listaClientes, LOG listaLogs){
	char confirma;
	printf ("Insira os dados do cliente %d\n\nNome: ", qtd.Clientes + 1);
	fflush(stdin);
	fgets(listaClientes.nome, 100, stdin);
	listaClientes.nome[strlen(listaClientes.nome) - 1] = '\0';
	printf ("Insira o endere�o: ");
	fgets(listaClientes.endereco, 100, stdin);
	listaClientes.endereco[strlen(listaClientes.endereco) - 1] = '\0';
	listaClientes.id = qtd.Clientes + 1;
	listaClientes.saldoDevedor = 0.0;
	listaClientes.diasDevidos = 0;
	listaClientes.jurosDevidos = 0;
	listaClientes.totalDevidos = 0;
	listaClientes.compras = 0;
	printf ("\nCODIGO\tNOME\tENDERE�O\tSALDO DEVEDOR\n%d\t%s\t%s\t%2.2f\n\nConfirma o cadastro do cliente (s/n)? ", listaClientes.id, listaClientes.nome, listaClientes.endereco, listaClientes.saldoDevedor);
	scanf(" %c", &confirma);
	if (confirma == 'n') return qtd.Clientes;
	else{
		//void gravarDados(int tipo, URL end, TYPEDEF nomedavariavel){
		FILE *p = fopen (end.clientes, "ab");
		fwrite(&listaClientes, sizeof(CLIENTES), 1, p);
		fclose(p);
		qtd.Clientes++;
		// gravando no log
		listaLogs.cod = 1;
		listaLogs.id = qtd.Clientes;
		pegaInstante(listaLogs.momento);
		strcpy(listaLogs.nome, listaClientes.nome);
		listaLogs.precoNovo = listaClientes.totalDevidos;
		p = fopen (end.log, "ab");
		fwrite(&listaLogs, sizeof(LOG), 1, p);
		fclose(p);
		return qtd.Clientes;
	}
}

//
void alteraClientes(URL end, DADOS qtd, CLIENTES listaClientes, LOG listaLogs){
	int id, opcao;
	char nome[100], endereco[100], confirma;
	cabecalho(qtd);                            										  // imprime o cabe�alho b�sico
	imprimeClientes(1, end, qtd, listaClientes);                                      // imprime todos os clientes cadastrados
	printf ("\nQual id do cliente que deseja alterar? ");
	do{ 																			  //
		scanf("%d", &id);															  //
		if (id < 1 || id > qtd.Clientes){											  //
			FOREYELLOW;																  //  -------- pega o id do cliente a ser alterado
			printf ("\nID inexistente, tente novamente: ");							  //
			FOREWHITE;																  //
		}																			  //
	} while (id < 1 || id > qtd.Clientes);											  //
	id--; 																			  // diminui 1 do ID para procurar corretamente
	//buscar no arquivo
	FILE *p = fopen(end.clientes, "rb");
	fseek(p, id * sizeof(CLIENTES),SEEK_SET);
	fread(&listaClientes, sizeof(CLIENTES), 1, p);
	fclose(p);
	printf ("\n%d\t%s\t%s\t%2.2f\n", listaClientes.id, listaClientes.nome, listaClientes.endereco, listaClientes.saldoDevedor);
	printf ("\nO que desejas alterar?\n1 - Nome\n2 - Endere�o\n\nEscolha sua op��o: ");
	do{
		scanf("%d", &opcao);
		if (opcao < 1 || opcao > 2){
			FOREYELLOW;
			printf ("ID inexistente, tente novamente: ");
			FOREWHITE;
		}
	} while (opcao < 1 || opcao > 2);
	fflush(stdin);
	switch(opcao){
		case 1:
			printf ("Digite o novo nome: ");
			fgets(nome, 100, stdin);
			nome[strlen(nome) - 1] = '\0';
			break;
		case 2:
			printf ("Digite o endere�o: ");
			fgets(endereco, 100, stdin);
			endereco[strlen(endereco) - 1] = '\0';
			break;
	}
	fflush(stdin);
	printf ("\nConfirma as altera��es? ");
	do{
		fflush(stdin);
		scanf ("%c", &confirma);
		if (confirma != 's' && confirma != 'n'){
			FOREYELLOW;
			printf ("\nOp��o inv�lida, tente novamente: ");
			FORERED;
		}
	} while(confirma != 's' && confirma != 'n');
	// se confirmar a altera��o feita
	if(confirma == 's'){
		p = fopen(end.clientes, "r+b");  // modo sobrescrever dados
		listaLogs.cod = 2;
		listaLogs.opcao = opcao;
		listaLogs.id = listaClientes.id;
		if(opcao == 1){
			strcpy(listaLogs.nomeVelho, listaClientes.nome);
			strcpy(listaClientes.nome, nome);
			strcpy(listaLogs.nome, nome);
		}
		else{
			strcpy(listaLogs.enderecoVelho, listaClientes.endereco);
			strcpy(listaClientes.endereco, endereco);
			strcpy(listaLogs.endereco, endereco);
		}
		pegaInstante(listaLogs.momento);
		printf ("\n%d\t%s\t%s\t%2.2f\n", listaClientes.id, listaClientes.nome, listaClientes.endereco, listaClientes.totalDevidos);
		fseek(p, id * sizeof(CLIENTES), SEEK_SET);
		fwrite(&listaClientes, sizeof(CLIENTES), 1, p);
		fclose(p);	
		//grava no log
		p = fopen (end.log, "ab");
		fwrite(&listaLogs, sizeof(LOG), 1, p);
		fclose(p);		
	}
}

// imprime os clientes recebendo como o primeiro parametro a opcao 
void imprimeClientes(int num, URL end, DADOS qtd, CLIENTES listaClientes){
	int i, cliente;
	CLIENTES lista[qtd.Clientes];
	if (qtd.Clientes == 0) printf ("\nN�o h� clientes cadastrados...");
	else{
		FILE *p = fopen(end.clientes, "rb");
		fread(&lista, sizeof(CLIENTES), qtd.Clientes, p);
		fclose(p);
		switch(num){
			case 1: //todos os clientes
				printf ("\nCODIGO\tNOME\tENDERE�O\tCOMPRAS\tSALDO DEVEDOR (c/ juros)\n");
				for(i = 0; i < qtd.Clientes; i++){ 
					printf("%d\t%s\t\t%s\t\t%d\t%2.2f\n", lista[i].id, lista[i].nome, lista[i].endereco, lista[i].compras, lista[i].totalDevidos);
				}
				break;
			case 2: //clientes devedores
				printf ("\nCODIGO\tNOME\tENDERE�O\tCOMPRAS\tSALDO DEVEDOR\n");
				for(i = 0; i < qtd.Clientes; i++){
					if(lista[i].saldoDevedor > 0) printf("%d\t%s\t%s\t%d\t%2.2f\n", lista[i].id, lista[i].nome, lista[i].endereco, lista[i].compras, lista[i].totalDevidos);
				}
				break;
			case 3: // clientes quitados
				printf ("\nCODIGO\tNOME\tENDERE�O\tSALDO DEVEDOR\n");
				for(i = 0; i < qtd.Clientes; i++){
					if(lista[i].saldoDevedor == 0) printf("%d\t%s\t%s\t%d\t%2.2f\n", lista[i].id, lista[i].nome, lista[i].endereco, lista[i].compras, lista[i].totalDevidos);
				}
				break;
			case 4: //procura compras de determinado clientes -= fazer novo c�digo =-
			
				break;
		}
	}		
}

int pegaId(URL end, DADOS qtd){
	int idVenda;
	CLIENTES listaClientes;
	do{
		cabecalho(qtd);
		imprimeClientes(1, end, qtd, listaClientes);
		if(qtd.Clientes == 0){
			printf ("\n\nAperte qualquer tecla para voltar ao menu principal...");
			getch();
			break;
		}
		printf ("\nEscolha o ID do cliente (insira 0 para sair): ");
		scanf ("%d", &idVenda);
		if(idVenda == 0) return;
		FILE *p = fopen (end.clientes, "rb");
		fseek(p, (idVenda - 1) * sizeof(CLIENTES), SEEK_SET);
		fread(&listaClientes, sizeof(CLIENTES), 1, p);
		fclose(p);
		if (idVenda < 0 || idVenda > qtd.Clientes){
			FOREYELLOW;
			printf ("ID inv�lido, tente novamente: ");
			FOREWHITE;
		}
		if(listaClientes.saldoDevedor > 50){
			FORERED;
			printf ("\nCLIENTE SUSPENSO\nO clientes %s tem uma d�vida de R$ %2.2f h� %d dias.\n", listaClientes.nome, listaClientes.totalDevidos, listaClientes.diasDevidos);
			FOREWHITE;
			printf ("\nAperte qualquer bot�o para tentar novamente...");
			idVenda = -1;
			getch();
		}
	} while (idVenda < 0 || idVenda > qtd.Clientes);
	
	return idVenda;
}

// --------------------------------------------------- //
// --------------                   ------------------ //
// --------------      PRODUTOS     ------------------ //
// --------------                   ------------------ //
// --------------------------------------------------- //

// cadastra produtos retornando a sua quantidade ap�s inscer��o ou n�o
int cadastraProdutos(URL end, DADOS qtd, PRODUTOS listaProdutos, LOG listaLogs){
	char confirma;
	printf ("Insira os dados do produtos %d\n\nNome: ", qtd.Produtos + 1);
	fflush(stdin);
	fgets(listaProdutos.nome, 100, stdin);
	listaProdutos.nome[strlen(listaProdutos.nome) - 1] = '\0';
	printf ("Qual a quantidade inicial de estoque dele? ");
	scanf("%d", &listaProdutos.qtd);
	printf ("Qual a quantidade critica de estoque? ");
	scanf ("%d", &listaProdutos.qtdBaixas);
	listaProdutos.cod = qtd.Produtos + 1;
	listaProdutos.qtdVendidas = 0;
	printf ("Qual o pre�o do produto? ");
	scanf("%f", &listaProdutos.preco);
	printf ("\nCODIGO\tNOME\t\t\tESTOQUE\tESTOQUE BAIXO\tPRE�O\n%d\t%s\t\t\t%d\t%d\t%2.2f\nConfirma o cadastro do produto (s/n)? ", listaProdutos.cod, listaProdutos.nome, listaProdutos.qtd, listaProdutos.qtdBaixas,listaProdutos.preco);
	scanf(" %c", &confirma);
	if (confirma == 'n') return qtd.Produtos;
	else{
		FILE *p = fopen (end.produtos, "ab");
		fwrite(&listaProdutos, sizeof(PRODUTOS), 1, p);
		fclose(p);
		qtd.Produtos++;
		//salvando no log
		pegaInstante(listaLogs.momento);
		strcpy(listaLogs.nome, listaProdutos.nome);
		listaLogs.cod               = 3;
		listaLogs.precoNovo         = listaProdutos.preco;
		listaLogs.estoqueAdicionado = listaProdutos.qtd;
		listaLogs.id                = qtd.Produtos;
		//listaLogs.id, listaLogs.nome, listaLogs.precoNovo, listaLogs.estoqueAdicionado)
		p = fopen(end.log, "ab");
		fwrite(&listaLogs, sizeof(LOG), 1, p);
		fclose(p);
		return qtd.Produtos;
	}
}

// altera as caracter�sticas de determinado produtos
void alteraProdutos(URL end, DADOS qtd, PRODUTOS listaProdutos, LOG listaLogs){
	int id, opcao;
	char nome[100], confirma;
	float preco;
	imprimeProdutos(1, end, qtd, listaProdutos);
	if (qtd.Produtos == 0){
		getch();
		return;
	}
	else{	
		printf ("\nQual o c�digo do produtos que deseja alterar? ");
		do{
			scanf("%d", &id);
			if (id < 1 || id > qtd.Produtos){
				FOREYELLOW;
				printf ("C�digo inexistente, tente novamente: ");
				FOREWHITE;
			}
		} while (id < 1 || id > qtd.Produtos);
		id--;
		//buscar no arquivo
		FILE *p = fopen(end.produtos, "rb");
		fseek(p, id * sizeof(PRODUTOS),SEEK_SET);
		fread(&listaProdutos, sizeof(PRODUTOS), 1, p);
		fclose(p);
		printf ("\n%d\t%s\t%2.2d\t%2.2f\n", listaProdutos.cod, listaProdutos.nome, listaProdutos.qtd, listaProdutos.preco);
		printf ("O que desejas alterar?\n1 - Nome\n2 - Pre�o\n\nEscolha sua op��o: ");
		do{
			scanf("%d", &opcao);
			if (opcao < 1 || opcao > 2){
				FOREYELLOW;
				printf ("C�digo inexistente, tente novamente: ");
				FOREWHITE;
			}
		} while (opcao < 1 || opcao > 2);
		fflush(stdin);
		switch(opcao){
			case 1:
				printf ("Digite o novo nome: ");
				fgets(nome, 100, stdin);
				nome[strlen(nome) - 1] = '\0';
				break;
			case 2:
				printf ("Digite o novo pre�o do produto: ");
				scanf ("%f", &preco);
				break;
		}
		fflush(stdin);
		printf ("\nConfirma as altera��es? ");
		do{
			fflush(stdin);
			scanf ("%c", &confirma);
			if (confirma != 's' && confirma != 'n'){
				FOREYELLOW;
				printf ("\nOp��o inv�lida, tente novamente: ");
				FORERED;
			}
		} while(confirma != 's' && confirma != 'n');
		if(confirma == 's'){
			p = fopen(end.produtos, "r+b");
			pegaInstante(listaLogs.momento);
			if(opcao == 1){
				strcpy(listaLogs.nomeVelho, listaProdutos.nome);
				strcpy(listaProdutos.nome, nome);
				strcpy(listaLogs.nome, listaProdutos.nome);
			}
			else{
				listaLogs.precoAnterior = listaProdutos.preco;
				listaProdutos.preco     = preco;
				listaLogs.precoNovo     = preco;
			}
			listaLogs.cod = 4;
			listaLogs.opcao = opcao;
			listaLogs.id = id + 1;
			fseek(p, id * sizeof(PRODUTOS), SEEK_SET);
			fwrite(&listaProdutos, sizeof(PRODUTOS), 1, p);
			fclose(p);
			// salva no LOG
			p = fopen (end.log, "ab");
			fwrite(&listaLogs, sizeof(LOG), 1, p);
			fclose(p);
		}
	}
}

// adiciona produtos no estoque
void adicionaEstoque(URL end, DADOS qtd, PRODUTOS listaProdutos, LOG listaLogs){
	int id, opcao, quantidade;
	char confirma;
	imprimeProdutos(1, end, qtd, listaProdutos);
	printf ("\nQual o c�digo do produtos que deseja alterar? ");
	do{
		scanf("%d", &id);
		if (id < 1 || id > qtd.Produtos){
			FOREYELLOW;
			printf ("C�digo inexistente, tente novamente: ");
			FOREWHITE;
		}
	} while (id < 1 || id > qtd.Produtos);
	id--;
	//buscar no arquivo
	FILE *p = fopen(end.produtos, "rb");
	fseek(p, id * sizeof(PRODUTOS),SEEK_SET);
	fread(&listaProdutos, sizeof(PRODUTOS), 1, p);
	fclose(p);
	cabecalho(qtd);
	printf ("\n%d\t%s\t%2.2d\t%2.2f\n", listaProdutos.cod, listaProdutos.nome, listaProdutos.qtd, listaProdutos.preco);
	printf ("Digite as unidades digitadas no estoque: ");
	scanf ("%d", &quantidade);
	quantidade += listaProdutos.qtd;
	printf ("O estoque desse produto ficar� com %d produtos, confirma (s/n)? ", quantidade);
	scanf (" %c", &confirma);
	if (confirma == 's'){
		pegaInstante(listaLogs.momento);
		listaLogs.cod = 5;
		listaLogs.estoqueAntigo = listaProdutos.qtd;
		listaProdutos.qtd = quantidade;
		listaLogs.estoqueAdicionado = listaProdutos.qtd;
		listaLogs.id = id + 1;
		p = fopen (end.produtos, "r+b");
		fseek (p, id * sizeof(PRODUTOS), SEEK_SET);
		fwrite (&listaProdutos, sizeof(PRODUTOS), 1, p);
		fclose(p);
		p = fopen (end.log, "ab");
		fwrite (&listaLogs, sizeof(LOG), 1, p);
		fclose(p);
		printf ("\nEstoque atualizado...");
		sleep(3);
	}
}


void imprimeProdutos(int num, URL end, DADOS qtd, PRODUTOS listaProdutos){
	int i;
	if (qtd.Produtos == 0) printf ("\nN�o h� produtos cadastrados...\n");
	else{
		FILE *p = fopen(end.produtos, "rb");
		printf ("\nCODIGO\tNOME\tQUANTIDADE\tPRE�O\n");
		switch(num){
			case 1: // apresenta todos os produtos
				for(i = 0; i < qtd.Produtos; i++){
					fread(&listaProdutos, sizeof(PRODUTOS), 1, p);
					printf("%d\t%s\t", listaProdutos.cod, listaProdutos.nome);
					if (listaProdutos.qtd < listaProdutos.qtdBaixas){
						FORERED;
						printf ("%2.2d", listaProdutos.qtd);
						FOREWHITE;
					}
					else printf ("%2.2d", listaProdutos.qtd);
					printf ("\t%2.2f\n",listaProdutos.preco);		
				}
				fclose(p);
				break;
			case 2: // apresenta produtos com baixo estoque
				
				for(i = 0; i < qtd.Produtos; i++){
					fread(&listaProdutos, sizeof(PRODUTOS), 1, p);
					if (listaProdutos.qtd < listaProdutos.qtdBaixas){
						printf("%d\t%s\t", listaProdutos.cod, listaProdutos.nome);
						FORERED;
						printf ("%2.2d", listaProdutos.qtd);
						FOREWHITE;
						printf ("\t%2.2f\n",listaProdutos.preco);
					}		
				}
				fclose(p);
				break;					
		}
	}
}

/* vende produtos para determinados clientes
   - para venda vista (id ==  0)
   - para venda fiado (id != 0)
*/
int vender(int id, URL end, DADOS qtd, CLIENTES listaClientes, PRODUTOS listaProdutos, VENDAS listaVendas, LOG listaLogs){
	int i;
	int codigo;                                        // codigo do produto a ser escolhido
	int quantidade = 0;	                               // quantidade de produtos a serem inseridos
	int compra = 0;                                    // quantidade de itens da lista
	float compraTotal = 0;                             // receber� a compra do momento
	PRODUTOS produtos[qtd.Produtos];
	// pegar lista de produtos
	FILE *p = fopen(end.produtos, "rb");
	fread (&produtos, sizeof(PRODUTOS), qtd.Produtos, p);
	fclose(p);
	// se for a fiado pega as informa��es do cliente
	if (id != 0){
		FILE *p = fopen (end.clientes, "rb");
		fseek (p, (id - 1) * sizeof(CLIENTES), SEEK_SET);
		fread (&listaClientes, sizeof(CLIENTES), 1, p);
		fclose(p);
	}
	if (qtd.Produtos == 0){ // se a quantidade de produtos for 0 a fun��o n�o ser� executada
		FOREYELLOW;
		printf ("\nAdicione produtos para vender corretamente.");
		FOREWHITE;
		getch();
		return;
	}
	if (qtd.Clientes == 0 && id != 0){
		printf ("\nAdicione clientes na lista para vender a fiado corretamente");
		getch();
		return;
	}
	else{
		do{
			cabecalho(qtd);
			if (id != 0) printf ("Clientes %d selecionado (%s, %s SALDO DEVEDOR: %2.2f)\n", id, listaClientes.nome, listaClientes.endereco, listaClientes.saldoDevedor);
			printf ("TOTAL DA COMPRA = %2.2f\n", compraTotal);
			// imprime carrinho de compras 
			for(i = 0; i < compra; i++){
				if (i == 0){
					FORECYAN;
					printf ("\nCarrinho de compras:\n");	
					FOREWHITE;
				}
				printf ("%d\t%s\t%2.2d\t%2.2f\n", listaVendas.lista[i].cod, listaVendas.lista[i].nome, listaVendas.lista[i].quantidade, listaVendas.lista[i].preco);
			}
			//lista de produtos
			FORECYAN;
			printf ("\n* LISTA DE PRODUTOS *\n");
			FOREWHITE;
			//imprimeProdutos(1, end, qtd, listaProdutos);
			printf("CODIGO\tNOME\tQTD EM ESTOQUE\tPRE�O:\n");
			for(i = 0; i < qtd.Produtos; i++){
				printf ("%d\t%s\t%2.2d\t%2.2f\n", produtos[i].cod, produtos[i].nome, produtos[i].qtd, produtos[i].preco);
			}
			FOREYELLOW;
			printf ("\nPara fechar a compra digite 0 como c�digo do produto.\n");
			FOREWHITE;
			printf ("\nSelecione o c�digo do produto: ");
			do{
				scanf ("%d", &codigo);
				if (codigo < 0 || codigo > qtd.Produtos){
					FOREYELLOW;
					printf ("C�digo de produto inexistente, tente novamente: ");
					FOREWHITE;
				}
			} while (codigo < 0 || codigo > qtd.Produtos);
			if(codigo == 0) break; // se o c�digo for zero ele vai fechar o caixa
			else{ // sen�o vai salvando os novos itens na estrutura
				printf ("\nInsira a quantidade: ");
				do{
					scanf ("%d", &quantidade);
					if (produtos[codigo - 1].qtd - quantidade < 0 || quantidade < 0){
						FORERED;
						printf ("\nQuantidade inv�lida. Tente novamente: ");
						FOREWHITE;
					}
				} while(produtos[codigo - 1].qtd - quantidade < 0 || quantidade < 0);
				produtos[codigo - 1].qtd -= quantidade;                                         // diminui a quantidade comprada no estoque
				produtos[codigo - 1].qtdVendidas += quantidade;
				//compraTotal += (quantidade * listaProdutos.preco);                            // soma a quantidade com o total feita da compra at� ent�o
				// salva no carrinho
				listaVendas.lista[compra].cod = produtos[codigo - 1].cod;
				strcpy(listaVendas.lista[compra].nome, produtos[codigo - 1].nome);
				listaVendas.lista[compra].quantidade = quantidade;
				listaVendas.lista[compra].preco = quantidade * produtos[codigo - 1].preco;
				// conta mais um produto no carrinho
				compraTotal = compraTotal + listaVendas.lista[compra].preco;                    // adiciona a compra total da lista toda
				compra++;                                                                       // adiciona os itens da lista de compra
			}
		} while (codigo != 0);
		// fechar compra 
		if(compraTotal == 0) return; //se n�o houve compra alguma nada � gravado
		else{
			//grava a nova quantidade de produtos
			p = fopen (end.produtos, "wb");
			fwrite (&produtos, sizeof(PRODUTOS), qtd.Produtos, p);
			fclose(p);
			// gravar no log
			pegaInstante(listaLogs.momento);
			listaLogs.compraid = qtd.Vendas + 1;
			listaVendas.compraid = qtd.Vendas + 1;
			if (id == 0){ // a vista
				listaLogs.cod = 6;
				listaLogs.vendaTotal = compraTotal;
				listaVendas.quantidade = compra;	
				listaVendas.id = 0;
				listaVendas.compraTotal = compraTotal;
				pegaMomento(&listaVendas);
				// *** salvar na estrutura de vendas tamb�m ***
			}
			else{ // fiado
				//pegaDataCompleta(&listaVendas);
				listaVendas.compra = compraTotal;
				listaVendas.juros = 0;
				listaVendas.id = id;
				//listaVendas.quantidade++;
				listaVendas.quantidade = compra;
				listaVendas.saldoDevedor = compraTotal;
				listaVendas.compraTotal = compraTotal;
				pegaMomento(&listaVendas);
				listaClientes.compras++;
				listaLogs.cod = 7;
				listaLogs.id = id;
				listaLogs.vendaTotal = compraTotal;
				strcpy(listaLogs.nome, listaClientes.nome);
				pegaInstante(listaLogs.momento);
				//grava saldo atualizado
				listaClientes.totalDevidos += compraTotal;
				listaClientes.diasDevidos = 0;
				p = fopen(end.clientes, "r+b");
				fseek (p, (id - 1) * sizeof(CLIENTES), SEEK_SET);
				fwrite (&listaClientes, sizeof(CLIENTES), 1, p);
				fclose(p);
			}
			p = fopen(end.vendas, "ab");
			fwrite(&listaVendas, sizeof(VENDAS), 1, p);
			fclose(p);
			p = fopen(end.log, "ab");
			fwrite (&listaLogs, sizeof(LOG), 1, p);
			fclose(p);
		}
	}
	return qtd.Vendas;
}

void imprimeVendas(int num,URL end, DADOS qtd){
	VENDAS listaVendas[qtd.Vendas];
	int i, quitados = 0, devendo = 0;
	FILE *p = fopen (end.vendas, "rb");
	fread (&listaVendas, sizeof(VENDAS), qtd.Vendas, p);
	for(i = 0; i < qtd.Vendas; i++){
		if(listaVendas[i].saldoDevedor <= 0)  quitados++;
		if(listaVendas[i].saldoDevedor >  0)  devendo++;
	}
	if(qtd.Vendas == 0){
		printf ("N�o h� nenhuma venda registrada.\n\nAperte qualquer bot�o para continuar.");
		getch();
		return;
	}
	else{
		switch(num){
			case 1: // todas as vendas
				printf ("*** IMPRIMINDO TODAS AS VENDAS ***\n\nID\tCliente\tCompra\tVenda total\n");
				for(i = 0; i < qtd.Vendas; i++)	{
					if(listaVendas[i].id == 0) printf ("%d\t - \t%2.2f\ta vista\n", listaVendas[i].compraid, listaVendas[i].compraTotal);
					else printf ("%d\t%d\t%2.2f\t%2.2f\n", listaVendas[i].compraid, listaVendas[i].id, listaVendas[i].compraTotal ,listaVendas[i].saldoDevedor);
				}
				break;
			case 2: //vendas ativas
				if (devendo == 0){
					printf ("N�o h� vendas pendentes de pagamento.");
					return;
				}
				for(i = 0; i < qtd.Vendas; i++){
					if(listaVendas[i].saldoDevedor > 0) printf ("%d\t%d\t%2.2f\t%2.2f\n", listaVendas[i].compraid, listaVendas[i].id, listaVendas[i].compraTotal ,listaVendas[i].saldoDevedor);
				}
				break;
			case 3: //vendas quitadas
				if (quitados == 0){
					printf ("\nN�o h� vendas pendentes de pagamento.");
					return;
				}
				for(i = 0; i < qtd.Vendas; i++){
					if(listaVendas[i].saldoDevedor <= 0) printf ("%d\t%d\t%2.2f\t%2.2f\n", listaVendas[i].compraid, listaVendas[i].id, listaVendas[i].compraTotal ,listaVendas[i].saldoDevedor);
				}
				break;
			}	
		}
	
}
// fun��o que faz pagamento descontando das vendas mais antigas para as mais recentes
void fazPagamento(URL end, DADOS qtd, LOG listaLogs){
	int i;
	int id;											    // receber� o id de quem ir� pagar
	float pagamento; 									// receber� o pagamento que o cliente far�
	CLIENTES listaClientes[qtd.Clientes];
	VENDAS   listaVendas[qtd.Vendas];
	FILE *p = fopen (end.clientes, "rb");
	fread(&listaClientes, sizeof(CLIENTES), qtd.Clientes, p);
	fclose(p);
	p = fopen (end.vendas, "rb");
	fread(&listaVendas, sizeof(VENDAS), qtd.Vendas, p);
	fclose(p);
	printf ("Selecione 0 para voltar ao menu principal\n\nEscolha o ID do cliente: ");
	do{
		scanf("%d", &id);
		if (id == 0) return;   		// se o ID = 0 n�o ser� efetuado nenhum pagamento
		if(id < 0 || id > qtd.Clientes){
			FOREYELLOW;
			printf ("ID inv�lido, tente novamente: ");
			FOREWHITE;
		}
		if (listaClientes[id-1].saldoDevedor <= 0){
			FOREYELLOW;
			printf ("ID n�o possui d�bito, tente novamente: ");
			FOREWHITE;
		}
	} while((id < 0 || id > qtd.Clientes) || listaClientes[id-1].saldoDevedor <= 0);	 						
	id--;
	p = fopen(end.clientes, "rb");
	fseek(p, id * sizeof(CLIENTES), SEEK_SET);
	fwrite(&listaClientes, sizeof(CLIENTES), 1, p);
	fclose(p);
	printf ("Insira o montante a ser pago: ");
	scanf ("%f", &pagamento);
	listaLogs.cod = 8;
	listaLogs.pagamento = pagamento;
	listaLogs.id = id + 1;
	pegaInstante(listaLogs.momento);
	listaLogs.saldoAnterior = listaClientes[id].totalDevidos;
	listaLogs.saldoAtual = listaClientes[id].totalDevidos - pagamento;
	printf ("%2.2f %2.2f", listaLogs.saldoAnterior, listaLogs.saldoAtual);
	getch();
	if(pagamento == 0) return;
	else{
		for(i = 0; i < qtd.Vendas; i++){
			if(listaVendas[i].id == id + 1 && listaVendas[i].saldoDevedor > 0){
				if (pagamento <= listaVendas[i].saldoDevedor){
					listaVendas[i].saldoDevedor -= pagamento;
					pagamento = 0;
					break;
				}
				else{
					int resto = pagamento - listaVendas[i].saldoDevedor;
					listaVendas[i].saldoDevedor -= pagamento;
					pagamento = resto;
				}
			}
		}
	}
	//salva no log
	p = fopen(end.log, "ab");
	fwrite(&listaLogs, sizeof(LOG), 1, p);
	fclose(p);
	//salva a venda
	p = fopen(end.vendas, "wb");
	fwrite(&listaVendas, sizeof(VENDAS), qtd.Vendas, p);
	fclose(p);
	verificaSaldos(end, qtd);
}
// --------------------------------------------------- //
// --------------                   ------------------ //
// --------------       TEMPO       ------------------ //
// --------------                   ------------------ //
// --------------------------------------------------- //
// passa um vetor de caracteres por parametro e devolve hora, minuto e segundo (XXh:XXm:XXs)
void pegaInstante(char frase[]){
	int hora, min, seg;
	struct tm *data_hora_atual;
	time_t segundos;
	time(&segundos);
	data_hora_atual = localtime(&segundos);
	hora = data_hora_atual->tm_hour;
	min = data_hora_atual->tm_min;
	seg = data_hora_atual->tm_sec;
	snprintf (frase, 50, "%.2dh:%.2dm:%.2ds", hora, min, seg);
}

// passando a lista de vendas por parametro ele devolve o momento exato que a fun��o fora chamada (dia, mes, ano, hora, minuto e segundo)
void pegaMomento(VENDAS *listaVendas){
	struct tm *data_hora_atual;
	time_t segundos;
	time(&segundos);
	data_hora_atual = localtime(&segundos);
	listaVendas->dia = data_hora_atual->tm_mday;
	listaVendas->mes = data_hora_atual->tm_mon + 1;
	listaVendas->ano = data_hora_atual->tm_year + 1900;
	listaVendas->hora = data_hora_atual->tm_hour;
	listaVendas->min = data_hora_atual->tm_min;
	listaVendas->seg = data_hora_atual->tm_sec;	
}

//verifica bissexto retornando booleano
int verificaBissexto(int ano){
	if (ano % 4 == 0 && (ano % 100 != 0 || ano % 400 == 0)) return 1;
	else return 0;
}

// pega o dia da compra e retorna a quantidade de dias a frente
int verificaData(int dia, int mes, int ano){
	int bissexto = verificaBissexto(ano), diasAtuais = 0;
	mes--;
	do{
		if (mes == 2)                                           diasAtuais += 28;
		else if (mes == 2 && bissexto == 1)                     diasAtuais += 29;
		else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) diasAtuais += 30;
		else 													diasAtuais += 31;
		mes--;
	} while (mes != 0);
	diasAtuais += dia;
	return diasAtuais;
}
